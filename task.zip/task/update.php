<?php
include 'connect.php';
$id=$_GET['updateid'];
$sql="Select * from `employee` where id=$id";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($result);
        $firstname=$row['firstname'];
        $lastname=$row['lastname'];
        $birth=$row['birth'];
        $email=$row['email'];
        $phone=$row['phone'];
if(isset($_POST['submit'])){
  $firstname=$_POST['firstname'];
  $lastname=$_POST['lastname'];
  $birth=$_POST['birth'];
  $email=$_POST['email'];
  $phone=$_POST['phone'];

  $sql="update `employee` set id=$id,firstname='$firstname'
  ,lastname='$lastname',birth='$birth',email='$email',phone='$phone'
  where id =$id";
  
  $result=mysqli_query($con,$sql);
  if($result){

    header('location:display.php');
  }else{
    die(mysqli_error($con));
  }
}
  
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <title>mytask</title>
  </head>
  <body>
    <div class="contaner my-5">
    <form method="post">
  <div class="form-group">
    <label>Firstname</label>
    <input type="text" class="form-control" placeholder="Enter your name" name="firstname" auocomplete="off"
    value=<?php echo $firstname;?>>
  </div>
  <div class="form-group">
    <label>Lastname</label>
    <input type="text" class="form-control" placeholder="Enter your last name" name="lastname" auocomplete="off"
    value=<?php echo $lastname;?>>
  </div>
  <div class="form-group">
    <label>Date of birth</label>
    <input type="text" class="form-control" placeholder="Enter your Date of birth" name="birth" auocomplete="off"
    value=<?php echo $birth;?>>
  </div>
  <div class="form-group">
    <label>Email</label>
    <input type="email" class="form-control" placeholder="Enter your email" name="email" auocomplete="off"
    value=<?php echo $email;?>>
  </div>
  <div class="form-group">
    <label>Phone</label>
    <input type="text" class="form-control" placeholder="Enter your phone number" name="phone" auocomplete="off"
    value=<?php echo $phone;?>>
  </div>
    
  <button type="submit" class="btn btn-primary" name="submit">Update</button>
</form>
    </div>

  </body>
</html>