<?php
include 'connect.php';
if(isset($_POST['submit'])){
  $firstname=$_POST['firstname'];
  $lastname=$_POST['lastname'];
  $birth=$_POST['birth'];
  $email=$_POST['email'];
  $phone=$_POST['phone'];

  $sql="insert into employee (firstname,lastname,birth,email,phone)
  values('$firstname','$lastname','$birth','$email','$phone')";
  $result=mysqli_query($con,$sql);
  if($result){
  
    header('location:display.php');
  }else{
    die(mysqli_error($con));
  }
}
  
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <title>mytask</title>
  </head>
  <body>
    <div class="contaner my-5">
    <form method="post">
  <div class="form-group">
    <label>Firstname</label>
    <input type="text" class="form-control" placeholder="Enter your name" name="firstname" auocomplete="off">
  </div>
  <div class="form-group">
    <label>Lastname</label>
    <input type="text" class="form-control" placeholder="Enter your last name" name="lastname" auocomplete="off">
  </div>
  <div class="form-group">
    <label>Date of birth</label>
    <input type="date" class="form-control" placeholder="Enter your Date of birth" name="birth" auocomplete="off">
  </div>
  <div class="form-group">
    <label>Email</label>
    <input type="email" class="form-control" placeholder="Enter your email" name="email" auocomplete="off">
  </div>
  <div class="form-group">
    <label>Phone</label>
    <input type="text" class="form-control" placeholder="Enter your phone number" name="phone" auocomplete="off">
  </div>
    
  <button type="submit" class="btn btn-primary" name="submit">Submit</button>
</form>
    </div>

  </body>
</html>