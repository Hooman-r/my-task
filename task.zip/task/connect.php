<?php

$con=new mysqli('localhost','root','','task');
if(!$con)
 {
    die(mysqli_error($con));
 }

?>